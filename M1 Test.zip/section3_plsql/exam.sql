CREATE TABLE users(username VARCHAR2(20) PRIMARY KEY, password VARCHAR2(15),type VARCHAR2(10), email_id VARCHAR2(20),constraint type1 check(type in('seller','customer')));

***OUT PUT : CREATE TABLE succeeded.

-------------------------------------------------------------------------------

INSERT INTO users VALUES('John','john@123','seller','john@igate.com');
INSERT INTO users VALUES('Fazil','fazil@123','seller','fazil@igate.com');
INSERT INTO users VALUES('Jim','jim@123','customer','jim@igate.com');
INSERT INTO users VALUES('Rose','rose@123','seller','rose@igate.com');

****OUT PUT : 1 rows inserted
              1 rows inserted
              1 rows inserted
              1 rows inserted
---------------------------------------------------------------------------------------------
CREATE TABLE salesdata(id NUMBER PRIMARY KEY, owner_name VARCHAR2(20) references users(username), mobilename VARCHAR2(10),color VARCHAR2(15), description VARCHAR2(50), cost NUMBER, negotiable VARCHAR2(1)); 

INSERT INTO salesdata VALUES(101,'John','iPhone 6','Black Leather', 'Phone available in good working condition',40000,0);

INSERT INTO salesdata VALUES(102,'Rose','iPhone 6','Red','Phone available in good working condition',42000,0);

INSERT INTO salesdata VALUES(103,'Rose','iPhone 5S','Space Grey','Good Phone',37000,1);

INSERT INTO salesdata VALUES(104,'Fazil','iPhone 5C','White','Good Phone',27000,1);

INSERT INTO salesdata VALUES(105,'John','iPhone 5C','White','Good looking Phone',26000,1);


----------------------------------------------------------------------------------------------------------
CREATE SEQUENCE id_Seq START WITH 106;

*** OUT PUT:  CREATE SEQUENCE succeeded.
---------------------------------------------------------------------------------------------------------
1.) create or replace PROCEDURE mobile_details
(v_mname in salesdata.mobilename%TYPE)
as
cursor mobile_info is
      select u.username,u.email_id,s.mobilename,s.color,s.cost
      from users u,salesdata s
      where s.mobilename=v_mname and u.type='seller' and  u.username= s.mobilename;
Mobile_Doesn't_Exists exception;
v_count NUMBER;
begin
    select count(*) into v_count from salesdata where mobilename=v_mname;
    if v_count < 1 then
    raise Mobile_Doesn't_exists;
    end if;
    dbms_output.put_line('ownername'||'     '||'EmailID'||'         '||'mobileName'||'    '||'color'||'    ' ||'Cost');
    for sales_rec in mobile_info
    loop
        dbms_output.put_line(sales_rec.ownername||'     '||sales_rec.email||'     '||sales_rec.mobilename||'      '||sales_rec.color||'    '||sales_rec.cost);
    end loop;
    EXCEPTION
    when Mobile_doesnt_exists then
    dbms_output.put_line('Invalid Mobile Name');
end;

begin
mobile_details('iphone 6');
end;

***OUT PUT  : PROCEDURE mobile_details Compiled.

anonymous block completed
ownername   email_id        mobilename    color            cost
John        john@igate.com  iphone 6      Black Leather   40000
Rose        rose@igate.com  iphone 6      Red             42000

anonymous block completed
Invalid mobile name

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
2.)
  a.)
      SELECT  s.ownername,u.email_id,u.type
FROM
  salesdata s,users u  where u.username=s.owner_name and u.type and s.negotiable='1';

b.)

  alter table  salesdata modify  constraint check_types check(negotiable in('1','0'));
   
************************************************************************
3.)  insert into salesdata
values(id_seq.nextval,'john','iphone 6','Blue','Good Looking Phone',45000,1);


