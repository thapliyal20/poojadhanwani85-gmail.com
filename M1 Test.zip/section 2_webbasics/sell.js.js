function validate(form1)
{
	validForm=true;
	ownernameElement=form[0];
	if(ownernameElement.value=="")
	{
	alert("Name is empty");
	document.getElementById("text").innerHTML="";
	ownernameElement.focus();
	ownernameElement="";  
	validForm=false;
	return validForm;
	}
	if(/^[a-z]+$/i.test(nameElement.value) == false)
	{
		alert("Only Alphabets allowed");
		ownernameElement.focus();
		ownernameElement.value ="";
		validForm = false;
		return validForm;
		
	}
	if(validate(form1))
	{
	win.document.write("<b>OwnerName : </b>"+form[0].value+"<br/>");
<script>

var ch;
function choice(){
		 ch= document.forms[0].state.value;
		 post();
		}
	function post(){
		if(ch=="iphone 6"){
				document.getElementById("color").innerHTML="";
				document.getElementById("color").innerHTML+="<td><select name='iphone 6' id='iphone 6_Mobilename'>"+
									"<option value=''>Select Color</option>"+
									"<option value='Black Leather'>Black Leather</option>"+
									"<option value='Green Silicone'>Green Silicone</option>"+
									"<option value='Red'>Red</option>"+
									"</select>"+
								"</td>";
			
		}
		else if(ch=="iphone 5S"){
				document.getElementById("color").innerHTML="";
				document.getElementById("color").innerHTML+="<td><select name='iphone 5S' id='iphone 5S_Mobilename'>"+
									"<option value=''>Select Color</option>"+
									"<option value='Gold'>Gold</option>"+
									"<option value='Silver'>Silver</option>"+
									"<option value='Space Grey'>Space Grey</option>"+
									"</select>"+
				
								"</td>";
		
		}
		else if(ch=="iphone 5C"){
		
				document.getElementById("color").innerHTML="";
				document.getElementById("color").innerHTML+="<td><select name='iphone 5C' id='iphone 5C_Mobilename'>"+
									"<option value=''>Select Color</option>"+
									"<option value='Yellow'>Yellow</option>"+
									"<option value='Pink'>Pink</option>"+
									"<option value='White'>White</option>"+
									"<option value='Blue'>Blue</option>"+
									"</select>"+
								"</td>";
		
		}
		
		else{
			document.getElementById("color").innerHTML="<select><option value=''>select color</option>";;
			alert("Please select a color");
		}
	}
</script>